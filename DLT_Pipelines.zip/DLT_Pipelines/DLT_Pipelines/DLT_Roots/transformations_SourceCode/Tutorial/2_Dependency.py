# import dlt
# from pyspark.sql.functions import *
# from pyspark.sql.types import *

# # Creating An End-To-End Basic Pipleline

# # Staging Area

# @dlt.table(
#     name = "staging_orders"
# )
# def staging_orders():

#     df = spark.readStream.table("dlt_cdc_scd.source.orders")
#     return df


# #Creating Transformed Table

# @dlt.view(
#     name = "transform_orders"
# )
# def transform_order():
#     df = spark.readStream.table("staging_orders")
#     df = df.withColumn("order_status", upper(col("order_status")))
#     return df

# #Creating Aggregate Area
# @dlt.table(
#     name = "aggregated_orders"
# )
# def aggregated_orders():
#     df = spark.readStream.table("transform_orders")
#     df = df.groupBy("order_status").count()
#     return df
