# Databricks notebook source
# MAGIC %md
# MAGIC ## Create Catalog

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG car_catalogs;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Schema
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA car_catalogs.silver

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA car_catalogs.gold

# COMMAND ----------

