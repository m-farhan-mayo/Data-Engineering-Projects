# Databricks notebook source
# MAGIC %md
# MAGIC ## Create Flag Parameter

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import DeltaTable

# COMMAND ----------

dbutils.widgets.text('incremental_flag', '0')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Flag For Initial Run And Incremental Run

# COMMAND ----------

incremental_flag = dbutils.widgets.get('incremental_flag')
display(incremental_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Dimension Model

# COMMAND ----------

# MAGIC %md
# MAGIC ### Fetching Required Columns

# COMMAND ----------

df_src = spark.sql('''
                   SELECT DISTINCT (Branch_ID) AS Branch_ID, BranchName
                   FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`
                   ''')

display(df_src)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DIM Model Sink Initial And Incremental

# COMMAND ----------

if spark.catalog.tableExists('car_catalogs.gold.dim_branch'):
    df_sink = spark.sql('''
                        SELECT dim_branch_key, Branch_ID, BranchName
                        FROM car_catalogs.gold.dim_branch
                    ''')
else:
    df_sink = spark.sql('''
                        SELECT 1 AS dim_branch_key, Branch_ID, BranchName
                        FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`
                        WHERE 1 = 0;
                    ''')

# COMMAND ----------

display(df_sink)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filtering New And Old Record

# COMMAND ----------

df_filter = df_src.join(df_sink, df_src.Branch_ID == df_sink.Branch_ID, "left").select(df_src.Branch_ID, df_src.BranchName, df_sink.dim_branch_key)

# COMMAND ----------

# MAGIC %md
# MAGIC **df_filter_old**

# COMMAND ----------

df_filter_old = df_filter.filter(col('dim_branch_key').isNull()).select(df_src['Branch_ID'], df_src['BranchName'])

# COMMAND ----------

# MAGIC %md
# MAGIC **df_filter_new**

# COMMAND ----------

df_filter_new = df_filter.filter(col('dim_branch_key').isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Surrogate Key

# COMMAND ----------

# MAGIC %md
# MAGIC **Fetch The Max Surrogate Key From Existing Table**

# COMMAND ----------

if incremental_flag == '0' or not spark.catalog.tableExists('car_catalogs.gold.dim_branch'):
    max_value = 1
else:
    max_value_df = spark.sql('SELECT MAX(dim_branch_key) FROM car_catalogs.gold.dim_branch')
    max_value = max_value_df.collect()[0][0]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Surrogate Key Column And Add Max Key

# COMMAND ----------

df_filter_new = df_filter_new.withColumn('dim_branch_key', max_value + monotonically_increasing_id())

# COMMAND ----------

display(df_filter_new)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Df = Old_df + new_df

# COMMAND ----------

df_filter_old = df_filter_old.withColumn("dim_branch_key", lit(None))

df_final = df_filter_new.union(df_filter_old)

# COMMAND ----------

display(df_final)

# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD TYPE 1(UPSERT) 

# COMMAND ----------

# Incremental Run
if spark.catalog.tableExists('car_catalogs.gold.branch_model'):
    delta_tbl = DeltaTable.forPath(spark, 'abfss://gold@jobready4azuredatabricks.dfs.core.windows.net/car_catalogs/gold/dim_branch')

    delta_tbl.alias('trg').merge(
        df_final.alias('src'),
        'trg.dim_branch_key = src.dim_branch_key'
    ).whenMatchedUpdateAll()\
     .whenNotMatchedInsertAll()\
     .execute()


else:
    df_final.write.format('delta')\
        .mode('overwrite')\
        .option('path', 'abfss://gold@jobready4azuredatabricks.dfs.core.windows.net/car_catalogs/gold/dim_branch')\
        .saveAsTable('car_catalogs.gold.dim_branch')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM car_catalogs.gold.dim_branch

# COMMAND ----------

