# Databricks notebook source
# MAGIC %md
# MAGIC ## Creating Fact Table

# COMMAND ----------

# MAGIC %md
# MAGIC **Reading Silver Data**

# COMMAND ----------

df_silver = spark.sql("SELECT * FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`")

# COMMAND ----------

# MAGIC %md
# MAGIC **Reading All Dims**

# COMMAND ----------

df_dealer = spark.sql("SELECT * FROM car_catalogs.gold.dim_dealer")

df_branch = spark.sql("SELECT * FROM car_catalogs.gold.dim_branch")

df_date = spark.sql("SELECT * FROM car_catalogs.gold.dim_date")

df_model = spark.sql("SELECT * FROM car_catalogs.gold.dim_model")

# COMMAND ----------

# MAGIC %md
# MAGIC **Bring All Keys To Facts**

# COMMAND ----------

df_fact = df_silver.join(df_branch, df_silver['Branch_ID'] == df_branch['Branch_ID'])\
                    .join(df_date, df_silver['Date_ID'] == df_date['Date_ID'])\
                    .join(df_dealer, df_silver['Dealer_ID'] == df_dealer['Dealer_ID'])\
                    .join(df_model, df_silver['Model_ID'] == df_model['Model_ID'])\
                    .select(df_silver['Revenue'],df_silver['Units_Sold'],df_silver['CostPerUnit'], df_dealer['dim_dealer_key'], df_branch['dim_branch_key'], df_date['dim_date_key'], df_model['Dim_Model_Key'])

# COMMAND ----------

display(df_fact)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Writing Facts Table

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

# Incremental Run
if spark.catalog.tableExists('factsales'):
    deltatbl = DeltaTable.forName(spark, 'car_catalogs.gold.factsales')

    deltatbl.alias('trg').merge(
        df_fact.alias('src'),
        'trg.dim_dealer_key = src.dim_dealer_key and trg.dim_branch_key = src.dim_branch_key and trg.dim_date_key = src.dim_date_key and trg.Dim_Model_Key = src.Dim_Model_Key'
    ).whenMatchedUpdateAll()\
     .whenNotMatchedInsertAll()\
     .execute()


else:
    df_fact.write.format('delta')\
        .mode('overwrite')\
        .option('path', 'abfss://gold@jobready4azuredatabricks.dfs.core.windows.net/car_catalogs/gold/factsales')\
        .saveAsTable('car_catalogs.gold.factsales')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM car_catalogs.gold.factsales

# COMMAND ----------

