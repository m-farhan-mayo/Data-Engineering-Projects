# Databricks notebook source
# MAGIC %md
# MAGIC ## Create Flag Parameter

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import DeltaTable

# COMMAND ----------

dbutils.widgets.text('incremental_flag', '0')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Flag For Initial Run And Incremental Run

# COMMAND ----------

incremental_flag = dbutils.widgets.get('incremental_flag')
display(incremental_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Dimension Model

# COMMAND ----------

# MAGIC %md
# MAGIC ### Fetching Required Columns

# COMMAND ----------

df_src = spark.sql('''
                   SELECT DISTINCT(Model_ID) as Model_ID , Model_Category
                   FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`
                   ''')

# COMMAND ----------

display(df_src)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DIM Model Sink Initial And Incremental

# COMMAND ----------

if spark.catalog.tableExists('car_catalogs.gold.dim_model'):
    df_sink = spark.sql('''
                        SELECT dim_model_key, Model_ID, Model_Category
                        FROM car_catalogs.gold.dim_model
                    ''')
else:
    df_sink = spark.sql('''
                        SELECT 1 AS dim_model_key, Model_ID, Model_Category
                        FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`
                        WHERE 1 = 0;
                    ''')

# COMMAND ----------

display(df_sink)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filtering New And Old Record

# COMMAND ----------

df_filter = df_src.join(df_sink, df_src.Model_ID == df_sink.Model_ID, "left").select(df_src.Model_ID, df_src.Model_Category, df_sink.dim_model_key)

# COMMAND ----------

# MAGIC %md
# MAGIC **df_filter_old**

# COMMAND ----------

df_filter_old = df_filter.filter(col('dim_model_key').isNull()).select(df_src['Model_ID'], df_src['Model_Category'])

# COMMAND ----------

# MAGIC %md
# MAGIC **df_filter_new**

# COMMAND ----------

df_filter_new = df_filter.filter(col('dim_model_key').isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Surrogate Key

# COMMAND ----------

# MAGIC %md
# MAGIC **Fetch The Max Surrogate Key From Existing Table**

# COMMAND ----------

if incremental_flag == '0' or not spark.catalog.tableExists('car_catalogs.gold.dim_model'):
    max_value = 1
else:
    max_value_df = spark.sql('SELECT MAX(dim_model_key) FROM car_catalogs.gold.dim_model')
    max_value = max_value_df.collect()[0][0]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Surrogate Key Column And Add Max Key

# COMMAND ----------

df_filter_new = df_filter_new.withColumn('Dim_Model_Key', max_value + monotonically_increasing_id())

# COMMAND ----------

display(df_filter_new)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Df = Old_df + new_df

# COMMAND ----------

df_filter_old = df_filter_old.withColumn("dim_model_key", lit(None))

df_final = df_filter_new.union(df_filter_old)

# COMMAND ----------

display(df_final)

# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD TYPE 1(UPSERT) 

# COMMAND ----------

# Incremental Run
if spark.catalog.tableExists('car_catalogs.gold.dim_model'):
    delta_tbl = DeltaTable.forPath(spark, 'abfss://gold@jobready4azuredatabricks.dfs.core.windows.net/car_catalogs/gold/dim_model')

    delta_tbl.alias('trg').merge(
        df_final.alias('src'),
        'trg.dim_model_key = src.Dim_Model_Key'
    ).whenMatchedUpdateAll()\
     .whenNotMatchedInsertAll()\
     .execute()


else:
    df_final.write.format('delta')\
        .mode('overwrite')\
        .option('path', 'abfss://gold@jobready4azuredatabricks.dfs.core.windows.net/car_catalogs/gold/dim_model')\
        .saveAsTable('car_catalogs.gold.dim_model')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM car_catalogs.gold.dim_model

# COMMAND ----------

