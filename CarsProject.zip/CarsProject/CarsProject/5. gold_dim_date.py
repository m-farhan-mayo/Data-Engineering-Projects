# Databricks notebook source
# MAGIC %md
# MAGIC ## Create Flag Parameter

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import DeltaTable

# COMMAND ----------

dbutils.widgets.text('incremental_flag', '0')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Flag For Initial Run And Incremental Run

# COMMAND ----------

incremental_flag = dbutils.widgets.get('incremental_flag')
display(incremental_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Dimension Model

# COMMAND ----------

# MAGIC %md
# MAGIC ### Fetching Required Columns

# COMMAND ----------

df_src = spark.sql('''
                   SELECT DISTINCT (Date_ID) AS Date_ID
                   FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`
                   ''')

display(df_src)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DIM Model Sink Initial And Incremental

# COMMAND ----------

if spark.catalog.tableExists('car_catalogs.gold.dim_date'):
    df_sink = spark.sql('''
                        SELECT dim_date_key,Date_ID
                        FROM car_catalogs.gold.dim_date
                    ''')
else:
    df_sink = spark.sql('''
                        SELECT 1 AS dim_date_key, Date_ID
                        FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`
                        WHERE 1 = 0;
                    ''')

# COMMAND ----------

display(df_sink)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filtering New And Old Record

# COMMAND ----------

df_filter = df_src.join(df_sink, df_src.Date_ID == df_sink.Date_ID, "left").select(df_src.Date_ID, df_sink.dim_date_key)

# COMMAND ----------

# MAGIC %md
# MAGIC **df_filter_old**

# COMMAND ----------

df_filter_old = df_filter.filter(col('dim_date_key').isNotNull()).select(df_src['Date_ID'])

# COMMAND ----------

# MAGIC %md
# MAGIC **df_filter_new**

# COMMAND ----------

df_filter_new = df_filter.filter(col('dim_date_key').isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Surrogate Key

# COMMAND ----------

# MAGIC %md
# MAGIC **Fetch The Max Surrogate Key From Existing Table**

# COMMAND ----------

if incremental_flag == '0' or not spark.catalog.tableExists('car_catalogs.gold.dim_date'):
    max_value = 1
else:
    max_value_df = spark.sql('SELECT MAX(dim_date_key) FROM car_catalogs.gold.dim_date')
    max_value = max_value_df.collect()[0][0]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Surrogate Key Column And Add Max Key

# COMMAND ----------

df_filter_new = df_filter_new.withColumn('dim_date_key', max_value + monotonically_increasing_id())

# COMMAND ----------

display(df_filter_new)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Df = Old_df + new_df

# COMMAND ----------

df_filter_old = df_filter_old.withColumn("dim_date_key", lit(None))

df_final = df_filter_new.union(df_filter_old)

# COMMAND ----------

display(df_final)

# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD TYPE 1(UPSERT) 

# COMMAND ----------

# Incremental Run
if spark.catalog.tableExists('car_catalogs.gold.date_model'):
    delta_tbl = DeltaTable.forPath(spark, 'abfss://gold@jobready4azuredatabricks.dfs.core.windows.net/car_catalogs/gold/dim_date')

    delta_tbl.alias('trg').merge(
        df_final.alias('src'),
        'trg.dim_date_key = src.dim_date_key'
    ).whenMatchedUpdateAll()\
     .whenNotMatchedInsertAll()\
     .execute()


else:
    df_final.write.format('delta')\
        .mode('overwrite')\
        .option('path', 'abfss://gold@jobready4azuredatabricks.dfs.core.windows.net/car_catalogs/gold/dim_date')\
        .saveAsTable('car_catalogs.gold.dim_date')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM car_catalogs.gold.dim_date

# COMMAND ----------

