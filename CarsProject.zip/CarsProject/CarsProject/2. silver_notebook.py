# Databricks notebook source
# MAGIC %md
# MAGIC ### Data Reading

# COMMAND ----------

df = spark.read.format("parquet")\
    .option("inferSchema", 'true')\
    .option("header", 'true')\
    .load('abfss://bronze@jobready4azuredatabricks.dfs.core.windows.net/rawdata')

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Transformation

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

df = df.withColumn('Model_Category', split(col('Model_ID'),'-')[0])\
    .withColumn('Model_Number', split(col('Model_ID'),'-')[1])
display(df)

# COMMAND ----------

df.withColumn('Units_Sold', col('Units_Sold').cast(StringType())).schema

# COMMAND ----------

df = df.withColumn('CostPerUnit',col('Revenue')/col('Units_Sold'))
display(df)

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## AD-HOC
# MAGIC

# COMMAND ----------

display(df.groupBy('Year','BranchName').agg(sum('Units_Sold').alias('Total_Units')).sort('Year', 'Total_Units', ascending=[1,0]))

# COMMAND ----------

df.write.format('parquet')\
    .mode('append')\
    .option('path', 'abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales')\
    .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Querying Silver Data

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM PARQUET.`abfss://sliver@jobready4azuredatabricks.dfs.core.windows.net/carsales`

# COMMAND ----------

