# Databricks notebook source
df = spark.read.format("csv")\
    .option("inferScheme", "true")\
    .option("header", "true")\
    .load("/Volumes/dbinterview/source/source_orders")

# COMMAND ----------

display(df)

# COMMAND ----------

df = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "csv")\
    .option("cloudFiles.schemaLocation", "/Volumes/dbinterview/source/bdsink/checkpoint")\
    .option("cloudFiles.schemaEvolutionMode", "rescue")\
    .option("cloudFiles.maxFilesPerTrigger", "1")\
    .load("/Volumes/dbinterview/source/source_orders")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME dbinterview.source.bdsink

# COMMAND ----------

df.writeStream.format("delta")\
    .option("checkpointLocation", "/Volumes/dbinterview/source/bdsink/checkpoint")\
    .trigger(once = True)\
    .start("/Volumes/dbinterview/source/bdsink/data")
