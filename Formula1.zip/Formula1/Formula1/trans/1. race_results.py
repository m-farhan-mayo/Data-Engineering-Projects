# Databricks notebook source
# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-21")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

constructor_df = spark.read.format("delta").load(f"{processed_folder_path}/constructors")\
    .withColumnRenamed("name", "team")

# COMMAND ----------

circuit_df = spark.read.format("delta").load(f"{processed_folder_path}/circuits")\
    .withColumnRenamed("location", "circuit_location")

# COMMAND ----------

driver_df = spark.read.format("delta").load(f"{processed_folder_path}/drivers")\
    .withColumnRenamed("number", "driver_number")\
    .withColumnRenamed("name", "driver_name")\
    .withColumnRenamed("nationality", "driver_nationality")

# COMMAND ----------

race_df = spark.read.format("delta").load(f"{processed_folder_path}/races")\
    .withColumnRenamed("name", "race_name")\
    .withColumnRenamed("race_timestamp", "race_date")

# COMMAND ----------

result_df = spark.read.format("delta").load(f"{processed_folder_path}/results")\
    .filter(f"file_date == '{v_file_data}'")\
    .withColumnRenamed("time", "race_time")\
    .withColumnRenamed("race_id", "result_race_id")

# COMMAND ----------

race_circuit_df = race_df.join(circuit_df, race_df.circuitId == circuit_df.circuitId, "inner")\
    .select(race_df.raceId, race_df.race_name, race_df.year, race_df.date, circuit_df.circuit_location)

# COMMAND ----------

race_result_df = result_df.join(race_circuit_df, result_df.result_race_id == race_circuit_df.raceId) \
    .join(driver_df, result_df.result_id == driver_df.driver_id)\
    .join(constructor_df, result_df.result_id == constructor_df.constructor_Id) 
    
display(race_result_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df = race_result_df.select("raceId", "year", "race_name", "date", "circuit_location", "driver_name", "driver_number", "driver_nationality", "team", "grid", "fastest_lap", "race_time", "points", "position")\
    .withColumn("Injection_Date", current_timestamp().alias("Injection_Date"))

# COMMAND ----------

display(final_df.filter("year == 2020 and race_name == 'Bahrain Grand Prix'").orderBy(final_df.points.desc()))

# COMMAND ----------

overwrite_partition(final_df, "f1_presentation", "race_results", "raceId")
