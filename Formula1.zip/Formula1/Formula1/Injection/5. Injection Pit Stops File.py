# Databricks notebook source
# MAGIC %md
# MAGIC #### Injecting Pit_Stop.Json File

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-21")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

from pyspark.sql.types import StructType, StringType, IntegerType, StructField
from pyspark.sql.functions import current_timestamp, lit

# COMMAND ----------

pit_stop_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                    StructField("driverId", IntegerType(), True),
                                    StructField("stop_id", IntegerType(), True),
                                    StructField("lap_number", IntegerType(), True),
                                    StructField("time", StringType(), True),
                                    StructField("duration", StringType(), True),
                                    StructField("milliseconds", IntegerType(), True)])

# COMMAND ----------

pit_stop_df = spark.read \
            .schema(pit_stop_schema)\
            .option("multiline", "true")\
            .json(f"{raw_folder_path}/{v_file_data}/pit_stops.json")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Renaming Adn Adding Columns
# MAGIC

# COMMAND ----------

final_pit = pit_stop_df.withColumnRenamed("driverId", "driver_id")\
                        .withColumnRenamed("raceId", "race_id")\
                        .withColumn("data_source", lit(v_data_source)) \
                        .withColumn("file_date", lit(v_file_data))\
                        .withColumn("Injection_Time", current_timestamp())

# COMMAND ----------

merge_condition= "tgt.race_id = src.race_id AND tgt.driver_id = src.driver_id AND tgt.race_id = src.race_id "
merge_delta_data(final_pit, 'f1_processed', 'pit_stops', processed_folder_path , merge_condition , 'race_id')

# COMMAND ----------

# MAGIC %sql 
# MAGIC --  DROP TABLE f1_processed.pit_stops

# COMMAND ----------

# final_pit.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.pit_stops")


# COMMAND ----------

dbutils.notebook.exit("Success")