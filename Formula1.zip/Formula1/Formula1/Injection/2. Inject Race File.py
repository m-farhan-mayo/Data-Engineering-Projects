# Databricks notebook source
# MAGIC %md
# MAGIC ##### Read a CSV File

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

from pyspark.sql.types import IntegerType, StringType, StructType, StructField
from pyspark.sql.functions import current_timestamp, to_timestamp, concat, lit, col

# COMMAND ----------

dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-21")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

race_schema = StructType(fields=[StructField("raceId", StringType(), False),
                                StructField("year", StringType(), True),
                                StructField("round", StringType(), True),
                                StructField("circuitId", IntegerType(), True),
                                StructField("name", IntegerType(), True),
                                StructField("date", IntegerType(), True),
                                StructField("time", StringType(), True),
                                StructField("url", IntegerType(), True),
                                 ])

# COMMAND ----------

races_df = spark.read \
    .option("header", True) \
    .schema(race_schema)\
    .csv(f"{raw_folder_path}/{v_file_data}/races.csv")

# COMMAND ----------

display(races_df)

# COMMAND ----------

time_stamp_df = races_df.withColumn("Injection_Time" , current_timestamp())\
                        .withColumn("Race_Time_Stamp", to_timestamp(concat(col('date') + lit(' '), col('time')), "yyyy-MM-dd HH:mm:ss"))\
                        .withColumn("data_source", lit(v_data_source)) \
                        .withColumn("file_date", lit(v_file_data))\
                        .show()

# COMMAND ----------

display(time_stamp_df)

# COMMAND ----------

races_df.select("raceId", "year", "round", "circuitId", "name",).show()

# COMMAND ----------

races_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.races")


# COMMAND ----------

dbutils.notebook.exit("Success")