# Databricks notebook source
dbutils.widgets.text("p_data_source", "testing")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-28")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, StringType, IntegerType, FloatType

# COMMAND ----------

result_schema = StructType(fields=[StructField("resultId", IntegerType(), False),
                StructField("raceId", IntegerType(), True),
                StructField("driverId", IntegerType(), True),
                StructField("constructorId", IntegerType(), True),
                StructField("number", FloatType(), True),
                StructField("grid", IntegerType(), True),
                StructField("position", StringType(), True),
                StructField("positionText", StringType(), True),
                StructField("positionOrder", IntegerType(), True),
                StructField("points", FloatType(), True),
                StructField("lap", IntegerType(), True),
                StructField("time", StringType(), True),
                StructField("milliseconds", IntegerType(), True),
                StructField("fastestLap", IntegerType(), True),
                StructField("rank", IntegerType(), True),
                StructField("fastestLapTime", StringType(), True),
                StructField("fastestLapSpeed", FloatType(), True),
                StructField("statusId", IntegerType(), True)])

# COMMAND ----------

result_df = spark.read \
    .schema(result_schema)\
    .json(f"{raw_folder_path}/{v_file_data}/results.json")

# COMMAND ----------

from pyspark.sql.functions import current_timestamp , lit

# COMMAND ----------

result_with_column_df = result_df.withColumnRenamed("resultId", "result_id")\
    .withColumnRenamed("raceId", "race_id")\
    .withColumnRenamed("driverId", "driver_id")\
    .withColumnRenamed("constructorId", "constructor_id")\
    .withColumnRenamed("positionText", "position_text")\
    .withColumnRenamed("positionOrder", "position_order")\
    .withColumnRenamed("fastestLap", "fastest_lap")\
    .withColumnRenamed("fastestLapTime", "fastest_lap_time")\
    .withColumnRenamed("fastestLapSpeed", "fastest_lap_speed")\
    .withColumn("injection_date", current_timestamp())\
    .withColumn("data_source", lit(v_data_source)) \
    .withColumn("file_date", lit(v_file_data))

# COMMAND ----------

from pyspark.sql.functions import col, desc

# COMMAND ----------

result_final_df = result_with_column_df.drop(col("statusId"))

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES

# COMMAND ----------

# MAGIC %md
# MAGIC ##Incremental Load

# COMMAND ----------

# MAGIC %md
# MAGIC ### Methode 1

# COMMAND ----------

# for race_id_list in result_final_df.select("race_id").distinct().collect():
#     if (spark._jsparkSession.catalog().tableExists("f1_processed.results")):
#         spark.sql(f"alter table f1_processed.results drop if exists partition (race_id = {race_id_list.race_id})")


# COMMAND ----------

# result_final_df.write.mode("append").format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- DROP TABLE f1_processed.results

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ### Methode 2

# COMMAND ----------

output_df = rearrange_partition_column(result_final_df, "race_id")

# COMMAND ----------

# MAGIC %sql
# MAGIC --DROP TABLE f1_processed.results

# COMMAND ----------

result_dedup_df = result_final_df.dropDuplicates(["race_id", "driver_id"])

# COMMAND ----------

merge_condition= "tgt.result_id = src.result_id  AND src.race_id = tgt.race_id AND tgt.stop = src.stop"
merge_delta_data(result_dedup_df, 'f1_processed', 'results', processed_folder_path , merge_condition , 'race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- DROP TABLE f1_processed.results

# COMMAND ----------

# overwrite_partition(result_final_df, "f1_processed", "results", "race_id")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT  race_id, COUNT(1)
# MAGIC FROM f1_processed.results
# MAGIC GROUP BY race_id
# MAGIC ORDER BY race_id DESC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id, driver_id, COUNT(1)
# MAGIC FROM f1_processed.results
# MAGIC GROUP BY race_id, driver_id
# MAGIC HAVING COUNT(1) > 1
# MAGIC ORDER BY race_id, driver_id DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.results WHERE race_id = 540 AND driver_id = 229

# COMMAND ----------

