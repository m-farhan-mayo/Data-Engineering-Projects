# Databricks notebook source
# MAGIC %run "../includes/Configuration"

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races")

# COMMAND ----------

display(races_df)

# COMMAND ----------

races_filter_df = races_df.filter("year > 2019 and round <= 5")

# COMMAND ----------

races_filer_df = races_df.filter((races_df["year"] == 2019) & (races_df["round"] <= 5))

# COMMAND ----------

display(races_filter_df)