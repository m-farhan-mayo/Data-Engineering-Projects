-- Databricks notebook source
USE f1_raw

-- COMMAND ----------

SELECT * FROM circuits

-- COMMAND ----------

DESC circuits

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_circuit
AS
SELECT circuitId, name, location, country
FROM circuits
WHERE country  = "USA"

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW y_circuit
AS
SELECT circuitId, name, location, country
FROM circuits
WHERE country  = "UK"

-- COMMAND ----------

SELECT * FROM y_circuit

-- COMMAND ----------

SELECT * FROM v_circuit

-- COMMAND ----------

-- MAGIC %md
-- MAGIC JOIN only gives the common on the both sides.

-- COMMAND ----------

SELECT *
FROM y_circuit y_uk
JOIN v_circuit v_usa
ON (y_uk.circuitId = v_usa.circuitId)

-- COMMAND ----------

SELECT *
FROM y_circuit y_uk
LEFT JOIN v_circuit v_usa
ON (y_uk.circuitId = v_usa.circuitId)

-- COMMAND ----------

SELECT *
FROM y_circuit y_uk
RIGHT JOIN v_circuit v_usa
ON (y_uk.circuitId = v_usa.circuitId)

-- COMMAND ----------

SELECT *
FROM y_circuit y_uk
FULL JOIN v_circuit v_usa
ON (y_uk.circuitId = v_usa.circuitId)

-- COMMAND ----------

SELECT *
FROM y_circuit y_uk
SEMI JOIN v_circuit v_usa
ON (y_uk.circuitId = v_usa.circuitId)

-- COMMAND ----------

SELECT *
FROM y_circuit y_uk
ANTI JOIN v_circuit v_usa
ON (y_uk.circuitId = v_usa.circuitId)

-- COMMAND ----------

SELECT *
FROM y_circuit y_uk
CROSS JOIN v_circuit v_usa
ON (y_uk.circuitId = v_usa.circuitId)

-- COMMAND ----------

