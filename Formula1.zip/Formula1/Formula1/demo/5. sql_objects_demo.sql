-- Databricks notebook source
-- MAGIC %run "../includes/Configuration"

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS demo;

-- COMMAND ----------

SHOW DATABASES

-- COMMAND ----------

DESCRIBE DATABASE EXTENDED demo

-- COMMAND ----------

SELECT current_database()

-- COMMAND ----------

show tables in demo

-- COMMAND ----------

USE demo

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## External TABLE

-- COMMAND ----------

-- MAGIC %run "../includes/Configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_result_df = spark.read.parquet(f"{presentation_folder_path}/race_results/")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_result_df.write.format("parquet").saveAsTable("demo.race_result")

-- COMMAND ----------

SHOW TABLES

-- COMMAND ----------

DESC EXTENDED race_result

-- COMMAND ----------

SELECT * FROM race_result WHERE year == 2019

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_result_df.write.format("parquet").option("path", f"{presentation_folder_path}/race_results_ext").saveAsTable("demo.race_result_ext")

-- COMMAND ----------

DESCRIBE EXTENDED race_result_ext

-- COMMAND ----------

CREATE TABLE demo.race_results_exte_sql (
    race_year INT,
    race_name STRING,
    race_date TIMESTAMP,
    circuit_location STRING,
    driver_name STRING,
    driver_number INT,
    driver_nationality STRING,
    team STRING,
    grid INT,
    fastest_lap INT,
    race_time STRING,
    points FLOAT,
    position INT,
    created_date TIMESTAMP
)
USING PARQUET
LOCATION "/mnt/databrick4storageaccount/presentation/race_results_ext_sql"


-- COMMAND ----------

SHOW TABLES IN demo

-- COMMAND ----------

INSERT INTO demo.race_results_exte_sql(
    race_year, race_name, race_date, circuit_location, driver_name,
    driver_number, driver_nationality, team, grid, fastest_lap,
    race_time, points, position, created_date
) VALUES
(2023, 'Bahrain Grand Prix', CAST('2023-03-05 18:00:00' AS TIMESTAMP), 'Sakhir', 'Max Verstappen', 1, 'Dutch', 'Red Bull Racing', 1, 1, '1:33:56.736', 25.0, 1, CURRENT_TIMESTAMP),
(2023, 'Saudi Arabian Grand Prix', CAST('2023-03-19 20:00:00' AS TIMESTAMP), 'Jeddah', 'Sergio Pérez', 11, 'Mexican', 'Red Bull Racing', 1, 1, '1:21:14.894', 25.0, 1, CURRENT_TIMESTAMP),
(2023, 'Australian Grand Prix', CAST('2023-04-02 17:00:00' AS TIMESTAMP), 'Melbourne', 'Fernando Alonso', 14, 'Spanish', 'Aston Martin', 4, 0, '2:32:38.371', 18.0, 4, CURRENT_TIMESTAMP),
(2022, 'Italian Grand Prix', CAST('2022-09-11 17:00:00' AS TIMESTAMP), 'Monza', 'Max Verstappen', 1, 'Dutch', 'Red Bull Racing', 7, 1, '1:20:27.511', 25.0, 1, CURRENT_TIMESTAMP),
(2022, 'Monaco Grand Prix', CAST('2022-05-29 16:00:00' AS TIMESTAMP), 'Monte Carlo', 'Sergio Pérez', 11, 'Mexican', 'Red Bull Racing', 3, 0, '1:56:30.265', 25.0, 1, CURRENT_TIMESTAMP),
(2021, 'Abu Dhabi Grand Prix', CAST('2021-12-12 17:00:00' AS TIMESTAMP), 'Yas Marina', 'Lewis Hamilton', 44, 'British', 'Mercedes', 2, 0, '1:30:17.345', 18.0, 2, CURRENT_TIMESTAMP);

-- COMMAND ----------

SELECT COUNT(1) FROM demo.race_results_exte_sql

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Views

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW Temp_View_SQL AS 
SELECT * 
FROM demo.race_results_exte_sql 
WHERE race_year == 2022

-- COMMAND ----------

CREATE OR REPLACE GlOBAL TEMP VIEW G_Temp_View_SQL AS 
SELECT * 
FROM demo.race_results_exte_sql 
WHERE race_year == 2023

-- COMMAND ----------

CREATE OR REPLACE VIEW P_View_SQL AS 
SELECT * 
FROM demo.race_results_exte_sql 
WHERE race_year == 2021

-- COMMAND ----------

SELECT * FROM Temp_View_SQL

-- COMMAND ----------

SELECT * FROM P_View_SQL