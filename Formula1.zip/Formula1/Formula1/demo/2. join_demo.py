# Databricks notebook source
# MAGIC %run "../includes/Configuration"

# COMMAND ----------

circuit_df = spark.read.parquet(f"{processed_folder_path}/races")

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Inner Join

# COMMAND ----------

race_circuit_df = races_df.join(circuit_df, races_df.circuitId == circuit_df.circuitId, "inner").select(races_df.circuitId, circuit_df.name,  races_df.year )

# COMMAND ----------

display(race_circuit_df)

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ### Left Outer Join
# MAGIC

# COMMAND ----------

race_circuit_df = races_df.join(circuit_df, races_df.circuitId == circuit_df.circuitId, "left")

# COMMAND ----------

display(race_circuit_df)

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ### Right Outer Join
# MAGIC

# COMMAND ----------

race_circuit_df = races_df.join(circuit_df, races_df.circuitId == circuit_df.circuitId, "right")

# COMMAND ----------

display(race_circuit_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Outer Join
# MAGIC

# COMMAND ----------

race_circuit_df = races_df.join(circuit_df, races_df.circuitId == circuit_df.circuitId, "outer")

# COMMAND ----------

display(race_circuit_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Semi Joins
# MAGIC ######Similar to inner joins
# MAGIC ############ we only get the data of left join part

# COMMAND ----------

race_circuit_df = races_df.join(circuit_df, races_df.circuitId == circuit_df.circuitId, "semi")

# COMMAND ----------

display(race_circuit_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Anti Join
# MAGIC ######## it show the right join data part

# COMMAND ----------

race_circuit_df = races_df.join(circuit_df, races_df.circuitId == circuit_df.circuitId, "anti")

# COMMAND ----------

display(race_circuit_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cross Join
# MAGIC ###### it gave all data in both side with duplicating it 

# COMMAND ----------

race_circuit_df = races_df.crossJoin(circuit_df)

# COMMAND ----------

#display(race_circuit_df)