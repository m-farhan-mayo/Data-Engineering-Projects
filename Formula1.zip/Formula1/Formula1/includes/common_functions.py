# Databricks notebook source
from pyspark.sql.functions import current_timestamp
def add_injection_date(input_df):
    output_df = input_df.withColumn("injection_date", current_timestamp())
    return output_df

# COMMAND ----------

def mount_adls(container_name):
  dbutils.fs.mount(
    source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
    mount_point = f"/mnt/{storage_account_name}/{container_name}",
    extra_configs = configs)

# COMMAND ----------

def overwrite_partition(input_df, db_name, table_name , partition_column):
    output_df = rearrange_partition_column(input_df, partition_column)

    spark.conf.set("spark.sql.source.partitionOverwriteMode", "dynamic")
    if (spark._jsparkSession.catalog().tableExists(f"{db_name}.{table_name}")):
        output_df.write.mode("overwrite").insertInto(f"{db_name}.{table_name}")
    else:
        output_df.write.mode("overwrite").partitionBy(partition_column).format("parquet").saveAsTable(f"{db_name}.{table_name}")



# COMMAND ----------

def rearrange_partition_column(input_df, partition_column):
    race_list = []
    for column_name in input_df.schema.names:
        if column_name != partition_column:
            race_list.append(column_name)
    race_list.append(partition_column)
    output_df = input_df.select(race_list)
    return output_df

# COMMAND ----------

def merge_delta_data(input_df, db_name, table_name, folder_path, merge_condition, partition_column):
    from delta.tables import DeltaTable

    if (spark._jsparkSession.catalog().tableExists(f"{db_name}.{table_name}")):
        deltaTable = DeltaTable.forPath(spark, f"{db_name}.{table_name}")
        deltaTable.alias("tgt").merge(
            input_df.alias("src"),
            merge_condition) \
            .whenMatchedUpdateAll() \
            .whenNotMatchedInsertAll() \
            .execute()
    else:
        input_df.write.mode("overwrite").partitionBy(partition_column).format("delta").saveAsTable(f"{db_name}.{table_name}") 

# COMMAND ----------

