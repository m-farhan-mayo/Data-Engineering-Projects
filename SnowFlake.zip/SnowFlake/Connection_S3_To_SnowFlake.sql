  // The CREATE STORAGE INTEGRATION command does not fetch the data itself, but rather ESTABLISH the secure, 
  // authorized CONNECTION that enables a future  command (like COPY INTO) to fetch the data.

CREATE STORAGE INTEGRATION SnowAWSCon
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = 'S3'
  ENABLED = TRUE
  STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::129401448873:role/snowflake-Data-csv-json-parquet'
  STORAGE_ALLOWED_LOCATIONS = ('s3://farhan-snowflake-data-ingestion/');



  // Use DESCRIBE to GET the DETAILS of INTEGRATION. So, Trust Relationship is set up using the correct STORAGE_AWS_IAM_USER_ARN and STORAGE_AWS_EXTERNAL_ID 

DESC INTEGRATION SnowAWSCon;


// The STAGE object defines the LOCATION and FORMAT of the data files (the "what" and "where").

CREATE OR REPLACE STAGE Snow_AWS_DATA_CSV
  storage_integration = SnowAWSCon
  URL = 's3://farhan-snowflake-data-ingestion/csvdata/'
  FILE_FORMAT = (TYPE = CSV, SKIP_HEADER = 1, NULL_IF = ('NULL', 'null', ''));

  
// For COPYING the DATA From S3 TO SnowFlake 
COPY INTO customers
            FROM @Snow_AWS_DATA_CSV


// Loading JSON Data FROM S3

CREATE OR REPLACE STAGE Snow_AWS_DATA_JSON
  storage_integration = SnowAWSCon
  URL = 's3://farhan-snowflake-data-ingestion/jsondata/'
  FILE_FORMAT = (TYPE = JSON, NULL_IF = ('NULL', 'null', ''));

SELECT * FROM @Snow_AWS_DATA_JSON;


CREATE OR REPLACE TABLE SNOWFLAKE_DB.SOURCE.JSON_DATA AS
SELECT 
    $1:asin::string AS asin,
    $1:helpful AS helpful,
    $1:overall::string AS overall,
    $1:reviewText::string AS reviewtext,
    DATE_FROM_PARTS(RIGHT($1:reviewTime::string, 4),
    LEFT($1:reviewTime::string, 2), 
    CASE WHEN SUBSTRING($1:reviewTime::string, 5, 1)=','
            THEN SUBSTRING($1:reviewTime::string, 4, 1)
            ELSE SUBSTRING($1:reviewTime::string, 4, 2) END) AS reviewtime,
    $1:reviewerID::string AS reviewerid,
    $1:reviewerName::string AS reviewername,
    $1:summary::string AS summary,
    DATE($1:unixReviewTime::INT) AS Revewtime
FROM @Snow_AWS_DATA_JSON;

SELECT * FROM SNOWFLAKE_DB.SOURCE.JSON_DATA;

CREATE OR REPLACE SCHEMA MANAGE_DB.PIPE;

CREATE OR REPLACE PIPE MANAGE_DB.PIPE.Emp_Pipe
auto_ingest = TRUE
AS 
    COPY INTO CUSTOMERS
    FROM @Snow_AWS_DATA_CSV;

DESC PIPE MANAGE_DB.PIPE.Emp_Pipe