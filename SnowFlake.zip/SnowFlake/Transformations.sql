CREATE OR REPLACE TABLE df_cust AS
SELECT customer_id, first_name, last_name, email, 
REGEXP_REPLACE(phone_number, '[^0-9]', '') as phone_number,city, signup_date,last_updated_timestamp
FROM customers;


CREATE OR REPLACE TABLE df_cust AS
SELECT customer_id,CONCAT(first_name, ' ',last_name)AS full_name,email,phone_number,city, signup_date,last_updated_timestamp
FROM df_cust;



CREATE OR REPLACE TABLE df_cust AS
SELECT customer_id,full_name,SPLIT_PART(email, '@', -1) AS domain_name ,email,phone_number,city, signup_date,last_updated_timestamp
FROM df_cust;


CREATE OR REPLACE TABLE df_cust AS
SELECT customer_id,full_name,email,domain_name,phone_number,city, signup_date,last_updated_timestamp,CURRENT_TIMESTAMP() as process_date
FROM df_cust;

SELECT * FROM df_cust

CREATE OR REPLACE TABLE df_cust AS
SELECT DISTINCT * FROM df_cust;

SELECT * FROM df_cust
