
    // Create file format and stage object
    
CREATE OR REPLACE FILE FORMAT MANAGE_DB.FILE_FORMATS.PARQUET_FORMAT
    TYPE = 'parquet';

CREATE OR REPLACE STAGE MANAGE_DB.EXTERNAL_STAGES.PARQUETSTAGE
    url = 's3://snowflakeparquetdemo'   
    FILE_FORMAT = MANAGE_DB.FILE_FORMATS.PARQUET_FORMAT;
    
    
    // Preview the data
    
LIST  @MANAGE_DB.EXTERNAL_STAGES.PARQUETSTAGE;   
    
SELECT * FROM @MANAGE_DB.EXTERNAL_STAGES.PARQUETSTAGE;

CREATE OR REPLACE TABLE SNOWFLAKE_DB.SOURCE.PARQUET_DATA AS
SELECT
    $1:__index_level_0__::integer AS index_Level,
    $1:cat_id::VARCHAR(50) AS Category,
    DATE($1:date::integer) AS date,
    $1:dept_id::VARCHAR(50) AS dept_id,
    $1:id::VARCHAR(50) AS id,
    $1:item_id::VARCHAR(50) AS item_id,
    $1:state_id::VARCHAR(50) AS state_id,
    $1:store_id::VARCHAR(50) AS store_id,
    $1:value::integer AS value
FROM
    @MANAGE_DB.EXTERNAL_STAGES.PARQUETSTAGE
    ORDER BY id

    SELECT * FROM SNOWFLAKE_DB.SOURCE.PARQUET_DATA