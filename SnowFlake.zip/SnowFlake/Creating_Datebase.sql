CREATE DATABASE IF NOT EXISTS snowflake_db;

CREATE SCHEMA IF NOT EXISTS source;

CREATE TABLE snowflake_db.source.customers(
    customer_id STRING,
    first_name STRING,
    last_name STRING,
    email STRING,
    phone_number STRING,
    city STRING,
    signup_date STRING,
    last_updated_timestamp STRING);

    SELECT * FROM customers

CREATE OR REPLACE TABLE df_cust AS
SELECT customer_id, first_name, last_name, email, 
REGEXP_REPLACE(phone_number, '[^0-9]', '') as phone_number,city, signup_date,last_updated_timestamp
FROM customers;

SELECT * FROM df_cust

CREATE OR REPLACE TABLE df_cust AS
SELECT customer_id,CONCAT(first_name, ' ',last_name)AS full_name,email,phone_number,city, signup_date,last_updated_timestamp
FROM df_cust;
