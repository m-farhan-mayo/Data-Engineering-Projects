from typing import list
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


class transformations:

    def dedup(self,df:DataFrame,dedup_cols:List,cdc:str):
        df = df.withColumn("dedup_key",concat(*dedup_cols))
        df = df.withColumn("count_dedup",row_number().over(Window.partitionBy("dedup_key").orderBy(desc(cdc))))
        df = df.filter(col("count_dedup")==1)
        df= df.drop("dedup_key","count_dedup")

        return df
    
    def process_time(self,df):
        df = df.withColumn("process_time",current_timestamp())
        return df
    
    def upsert(self,df,key_col,table,cdc):
        merge_condition = "AND".join([f"src.{i} = trg.{i}" for i in key_col])
        dlt_obj = DeltaTable.forName(f"pysparkdbt.silver.{table}")
        dlt_obj.alias("trg").merge(df.alias("src"), merge_condition)\
            .whenMatchedUpdateAll(condition= f"src.{cdc} >= trg.{cdc}")\
            .whenNotMatchedInsertAll()\
            .execute()

        return 1
