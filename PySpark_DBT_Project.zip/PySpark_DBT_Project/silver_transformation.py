# Databricks notebook source
import os
import sys

# COMMAND ----------

# from custom_utils import transformations

# COMMAND ----------

from typing import List
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from delta.tables import DeltaTable

# COMMAND ----------

class transformation:

    def dedup(self,df:DataFrame,dedup_cols:List,cdc:str):
        df = df.withColumn("dedup_key",concat(*dedup_cols))
        df = df.withColumn("count_dedup",row_number().over(Window.partitionBy("dedup_key").orderBy(desc(cdc))))
        df = df.filter(col("count_dedup")==1)
        df= df.drop("dedup_key","count_dedup")

        return df
    
    def process_time(self,df):
        df = df.withColumn("process_time",current_timestamp())
        return df
    
    def upsert(self,df,key_col,table,cdc):
        merge_condition = "AND".join([f"src.{i} = trg.{i}" for i in key_col])
        dlt_obj = DeltaTable.forName(spark,f"pysparkdbt.silver.{table}")
        dlt_obj.alias("trg").merge(df.alias("src"), merge_condition)\
            .whenMatchedUpdateAll(condition= f"src.{cdc} >= trg.{cdc}")\
            .whenNotMatchedInsertAll()\
            .execute()

        return 1
    
    def tran_number(self,df):
        df = df.withColumn('phone_number',regexp_replace("phone_number", r"[^0-9]",""))
        return df
    
    def last_name(self,df):
        df = df.withColumn("full_name", concat_ws(" ", col('first_name'), col('last_name')))
        df = df.drop('first_name', 'last_name')
        return df
    
    def domain(self,df):
        df = df.withColumn('domain',split(col('email'), '@')[1])
        return df



# COMMAND ----------

cust_obj = transformation()

# COMMAND ----------

# MAGIC %md
# MAGIC ## `CUSTOMERS`

# COMMAND ----------

df_cust = spark.read.table('pysparkdbt.bronze.customers')

# COMMAND ----------

df_cust = cust_obj.domain(df_cust)
df_cust = cust_obj.tran_number(df_cust)
df_cust = cust_obj.dedup(df_cust,['customer_id'],'last_updated_timestamp')
df_cust = cust_obj.process_time(df_cust)
df_cust = cust_obj.last_name(df_cust)


# COMMAND ----------

if not spark.catalog.tableExists('pysparkdbt.silver.customers'):

    df_cust.write.format('delta')\
        .mode('append')\
        .saveAsTable('pysparkdbt.silver.customers')

else:
    cust_obj.upsert(df_cust,['customer_id'],'customers','last_updated_timestamp')


# COMMAND ----------

# MAGIC %md
# MAGIC ## `DRIVERS`

# COMMAND ----------

df_drivers = spark.read.table("pysparkdbt.bronze.drivers")

# COMMAND ----------

driv_obj = transformation()

# COMMAND ----------

df_drivers = driv_obj.tran_number(df_drivers)
df_drivers = driv_obj.last_name(df_drivers)
df_drivers = driv_obj.dedup(df_drivers,['driver_id'],'last_updated_timestamp')
df_drivers = driv_obj.process_time(df_drivers)

display(df_drivers)


# COMMAND ----------

if not spark.catalog.tableExists('pysparkdbt.silver.drivers'):

    df_drivers.write.format('delta')\
        .mode('append')\
        .saveAsTable('pysparkdbt.silver.drivers')

else:
    driv_obj.upsert(df_drivers,['driver_id'],'drivers','last_updated_timestamp')


# COMMAND ----------

# MAGIC %md
# MAGIC ## `LOCATIONS`

# COMMAND ----------

df_locations = spark.read.table("pysparkdbt.bronze.locations")

# COMMAND ----------

loc_obj = transformation()

# COMMAND ----------

df_locations = loc_obj.dedup(df_locations,['location_id'],'last_updated_timestamp')
df_locations = loc_obj.process_time(df_locations)

# COMMAND ----------

display(df_locations)

# COMMAND ----------

if not spark.catalog.tableExists('pysparkdbt.silver.locations'):

    df_locations.write.format('delta')\
        .mode('append')\
        .saveAsTable('pysparkdbt.silver.locations')

else:
    loc_obj.upsert(df_locations,['location_id'],'locations','last_updated_timestamp')


# COMMAND ----------

# MAGIC %md
# MAGIC ## `PAYMENTS`

# COMMAND ----------

df_payments = spark.read.table("pysparkdbt.bronze.payments")

# COMMAND ----------

df_payments = df_payments.withColumn("Online_Payment",
                when(((col('payment_method')== "Card") & (col('payment_status')== "Success")), "online-success" )
              .when(((col('payment_method')== "Card") & (col('payment_status')== "Failed")), "online-failed" )
              .when(((col('payment_method')== "Card") & (col('payment_status')== "Pending")), "online-pending")
              .otherwise("offline"))

display(df_payments)

# COMMAND ----------

pay_obj = transformation()
df_payments = pay_obj.dedup(df_payments,['payment_id'],'last_updated_timestamp')
df_payments = pay_obj.process_time(df_payments)


# COMMAND ----------

if not spark.catalog.tableExists('pysparkdbt.silver.payments'):

    df_payments.write.format('delta')\
        .mode('append')\
        .saveAsTable('pysparkdbt.silver.payments')

else:
    pay_obj.upsert(df_payments,['payment_id'],'payments','last_updated_timestamp')


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM pysparkdbt.silver.payments

# COMMAND ----------

# MAGIC %md
# MAGIC ## `VEHICALS`

# COMMAND ----------

df_veh = spark.read.table("pysparkdbt.bronze.vehicles")

display(df_veh)

# COMMAND ----------

df_veh = df_veh.withColumn("make",upper(col("make")))
display(df_veh)

# COMMAND ----------

veh_obj = transformation()
df_veh = veh_obj.dedup(df_veh,['vehicle_id'],'last_updated_timestamp')
df_veh = veh_obj.process_time(df_veh)


if not spark.catalog.tableExists('pysparkdbt.silver.vehicles'):

    df_veh.write.format('delta')\
        .mode('append')\
        .saveAsTable('pysparkdbt.silver.vehicles')

else:
    veh_obj.upsert(df_veh,['customer_id'],'vehicles','last_updated_timestamp')


# COMMAND ----------

