# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### READING JSON DATA (BATCH)

# COMMAND ----------

# MAGIC %md
# MAGIC ### READING STREAMING DATA

# COMMAND ----------

my_schema = '''order_id STRING,
        timestamp STRING,
        customer STRUCT<
            customer_id: INT,
            name: STRING,
            email: STRING,
            address: STRUCT<
                city: STRING,
                country: STRING,
                postal_code: STRING>>,
        items ARRAY<STRUCT<
            item_id: STRING,
            price: DOUBLE,
            product_name: STRING,
            quantity: LONG
        >>,
        payment STRUCT<
            method: STRING,
            transaction_id: STRING>,
        metadata ARRAY<STRUCT<
            key: STRING,
            value: STRING
        >>

'''  

# COMMAND ----------

df = spark.readStream.format('json')\
          .option("multiline", "true")\
          .schema(my_schema)\
          .load('/Volumes/workspace/stream/streaming/jsonsource/')


#TRANSFORMATIONS
df = df.select('items', 'order_id', 'timestamp', 'customer.customer_id', 'customer.name', 'customer.email', 'customer.address.city', 'customer.address.country', 'customer.address.postal_code', 'payment', 'metadata')

df = df.select('items.item_id', 'items.price', 'items.product_name','items.quantity','order_id', 'timestamp', 'customer_id', 'name', 'email', 'city', 'country', 'postal_code', 'payment.method', 'payment.transaction_id', 'metadata' )

df= df.withColumn('metadata', explode_outer('metadata'))

df= df.select('*', 'metadata.key', 'metadata.value')


# COMMAND ----------

df.writeStream.format('delta')\
    .outputMode('append')\
    .trigger(once=True)\
    .option('path', '/Volumes/workspace/stream/streaming/jsonsink/Data')\
    .option('checkpointLocation', '/Volumes/workspace/stream/streaming/jsonsink/checkpoint')\
    .start() 

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM DELTA.`/Volumes/workspace/stream/streaming/jsonsink/Data`

# COMMAND ----------

# MAGIC %md
# MAGIC ### ARCHIVING

# COMMAND ----------

dbutils.fs.mkdirs('/Volumes/workspace/stream/streaming/jsonarchivesink')

# COMMAND ----------

df = spark.readStream.format('json')\
        .option("multiline", "true")\
        .schema(my_schema)\
        .option('sourceArchiveDir', '/Volumes/workspace/stream/streaming/jsonsourcearchive')\
        .load('/Volumes/workspace/stream/streaming/jsonsourcenew/')


#TRANSFORMATIONS
df = df.select('items', 'order_id', 'timestamp', 'customer.customer_id', 'customer.name', 'customer.email', 'customer.address.city', 'customer.address.country', 'customer.address.postal_code', 'payment', 'metadata')

df = df.select('items.item_id', 'items.price', 'items.product_name','items.quantity','order_id', 'timestamp', 'customer_id', 'name', 'email', 'city', 'country', 'postal_code', 'payment.method', 'payment.transaction_id', 'metadata' )

df= df.withColumn('metadata', explode_outer('metadata'))

df= df.select('*', 'metadata.key', 'metadata.value')


# COMMAND ----------

df.writeStream.format('delta')\
    .outputMode('append')\
    .trigger(once=True)\
    .option('path', '/Volumes/workspace/stream/streaming/jsonarchivesink/Data')\
    .option('checkpointLocation', '/Volumes/workspace/stream/streaming/jsonarchivesink/checkpoint')\
    .start() 

# COMMAND ----------

# df = spark.read.format('json')\
#           .option("multiline", "true")\
#           .option('inferSchema', 'true')\
#           .load('/Volumes/workspace/stream/streaming/jsonsource/')


# display(df)

# COMMAND ----------

# df = df.select('items', 'order_id', 'timestamp', 'customer.customer_id', 'customer.name', 'customer.email', 'customer.address.city', 'customer.address.country', 'customer.address.postal_code', 'payment', 'metadata')

# df = df.withColumn('items', explode_outer('items'))


# display(df)

# COMMAND ----------

# df = df.select('items.item_id', 'items.price', 'items.product_name','items.quantity','order_id', 'timestamp', 'customer_id', 'name', 'email', 'city', 'country', 'postal_code', 'payment.method', 'payment.transaction_id', 'metadata' )

# df.display()

# COMMAND ----------

# df= df.withColumn('metadata', explode_outer('metadata'))

# df= df.select('*', 'metadata.key', 'metadata.value')

# df= df.drop('metadata')

# df.display()

# COMMAND ----------

