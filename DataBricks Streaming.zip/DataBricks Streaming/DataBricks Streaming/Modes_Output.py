# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE workspace.stream.sourcetable
# MAGIC (
# MAGIC   color STRING
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

from delta.tables import *

# COMMAND ----------

DeltaTable.createIfNotExists(spark)\
    .tableName('workspace.stream.sourcetable')\
    .addColumn('color', 'STRING')\
    .execute()

# COMMAND ----------

DeltaTable.createIfNotExists(spark)\
    .tableName('workspace.stream.sinktable')\
    .addColumn('color', 'STRING')\
    .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO workspace.stream.sourcetable VALUES 
# MAGIC ('red'),
# MAGIC ('green'),
# MAGIC ('blue'),
# MAGIC ('yellow'),
# MAGIC ('orange'),
# MAGIC ('purple')
# MAGIC
# MAGIC     
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM workspace.stream.sourcetable

# COMMAND ----------

df = spark.readStream.table('workspace.stream.sourcetable')

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

df =df.groupBy('color').agg(count('*').alias('count'))

# COMMAND ----------

df.writeStream.format('delta')\
    .outputMode('complete')\
    .trigger(once=True)\
    .option('checkpointLocation', '/Volumes/workspace/stream/streaming/output/Check')\
    .option('path', '/Volumes/workspace/stream/streaming/output/Data')\
    .start()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM DELTA.`/Volumes/workspace/stream/streaming/output/Data`

# COMMAND ----------

