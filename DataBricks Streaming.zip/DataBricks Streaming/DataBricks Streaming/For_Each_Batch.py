# Databricks notebook source
df = spark.readStream.table('workspace.stream.sourcetable')

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

def myfunc(df, batchid):
    df =df.groupBy('color').agg(count('*').alias('count'))

    # DESTINATION 1
    df.write.format('delta')\
    .mode('append')\
    .option('path', '/Volumes/workspace/stream/streaming/foreachsink/dest1')\
    .save()

    # DESTINATION 2

    df.write.format('delta')\
    .mode('append')\
    .option('path', '/Volumes/workspace/stream/streaming/foreachsink/dest2')\
    .save()

# COMMAND ----------

df.writeStream.foreachBatch(myfunc)\
    .outputMode('append')\
    .trigger(once=True)\
    .option('checkpointLocation', '/Volumes/workspace/stream/streaming/foreachsink/checkpoint')\
    .start()