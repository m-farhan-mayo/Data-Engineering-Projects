--CREATE CREDENTIAL--
CREATE DATABASE SCOPED CREDENTIAL farhancreds
WITH
IDENTITY = 'Managed Identity';

--CREATE EXTERNAL DATA SOURCE--
CREATE EXTERNAL DATA SOURCE raw_ext_source
WITH
(
    LOCATION = 'https://igtechfarhannew.dfs.core.windows.net/raw',
    CREDENTIAL = farhancreds
)
--CREATE EXTERNAL DATA SOURCE--
CREATE EXTERNAL DATA SOURCE raw_ext_source_abfsss
WITH
(
    LOCATION = 'abfss://raw@igtechfarhannew.dfs.core.windows.net',
    CREDENTIAL = farhancreds
)

--CREATE PARQUET FORMAT--
CREATE EXTERNAL FILE FORMAT parquet_format
WITH
(
    FORMAT_TYPE = PARQUET,
    DATA_COMPRESSION = 'org.apache.hadoop.io.compress.SnappyCodec'
)