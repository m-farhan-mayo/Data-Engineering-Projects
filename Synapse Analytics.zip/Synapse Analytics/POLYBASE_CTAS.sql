--POLYBASE CTAS--
CREATE EXTERNAL TABLE parquet_table
(
    Dealer_ID VARCHAR(4000),
    Model_ID VARCHAR(4000),
    Branch_ID VARCHAR(4000),
    Date_ID VARCHAR(4000),
    Units_Sold BIGINT,
    Revenue BIGINT
)
WITH
(
    LOCATION = '/cetas_revenue',
    DATA_SOURCE = raw_ext_source_abfsss,
    FILE_FORMAT = parquet_format
)

--CTAS--
CREATE TABLE polytable
WITH(
    DISTRIBUTION = ROUND_ROBIN
)
AS
SELECT * FROM parquet_table



SELECT * FROM polytable