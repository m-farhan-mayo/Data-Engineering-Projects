# Databricks notebook source
dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/rawdata")

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/rawdata/customer")